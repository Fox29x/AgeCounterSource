my_age = 51
my_death = 81
while my_age < my_death:
    print (f"I am {my_age} and still alive")
    my_age += 1
print(f"But when I am {my_death}, I will not")